import sys
import urllib3
#import random
import RPi.GPIO as GPIO
from time import sleep

key = "PP4KH9E6ZBH7HE9L"  # Put your API Key here

baseURL = 'https://api.thingspeak.com/update?api_key=%s' %key

temp=0

#GPIO SETUP
channel = 17
GPIO.setmode(GPIO.BCM)
GPIO.setup(channel, GPIO.IN)
 
def callback(channel):
        if GPIO.input(channel):
                temp=GPIO.Reader()
                print ("Water Detected!")
        else:
                print ("Water Detected!")
 
GPIO.add_event_detect(channel, GPIO.BOTH, bouncetime=300)  # let us know when the pin goes HIGH or LOW
GPIO.add_event_callback(channel, callback)  # assign function to GPIO PIN, Run function on change




while True:
    try:
       # sens=random.random();

        
        #temp=(int)( ( 100-(sens) * 100 ) )
        baseURL += '&field1=%s' %temp
        #conn = urllib3.urlopen(baseURL + '&field1=%s' %temp)
        http = urllib3.PoolManager()
        
        
        x=http.request('GET', baseURL)
        print (baseURL)
        #conn.close()
        sleep(3)
    except:
        print("Error")
        
